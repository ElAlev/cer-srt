package edu.puc.flink;

public class CLI {

    public static String domain = "synthetic";

    public static void main(String[] args) throws Exception {
        domain = args[0];
        String[] newArgs = new String[args.length - 1];
        for (int i = 1, j = 0; i < args.length; i++) {
            newArgs[j++] = args[i];
        }
        if (domain.equalsIgnoreCase("synthetic")) {
            Synthetic.run(newArgs);
        }
        else if (domain.equalsIgnoreCase("stock")) {
            Stock.run(newArgs);
        }
        else if (domain.equalsIgnoreCase("smart")) {
            Smart.run(newArgs);
        }
        else if (domain.equalsIgnoreCase("taxi")) {
            Taxi.run(newArgs);
        }
        else {
            throw new IllegalArgumentException("what is this domain?");
        }
    }
}

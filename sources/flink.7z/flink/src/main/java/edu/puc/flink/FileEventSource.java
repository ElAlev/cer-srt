package edu.puc.flink;

import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;

import java.io.*;
import java.util.LinkedList;

public class FileEventSource extends RichParallelSourceFunction<Event> {
    private final String fileName;
    public static int events;


    FileEventSource(String streamFileName){
        fileName = streamFileName;
    }

    @Override
    public void run(SourceContext<Event> ctx) throws Exception {
        if (!Synthetic.memoryTest) {
            try {
                int timeout = Synthetic.timeout;
                FileReader file = new FileReader(fileName);
                BufferedReader reader = new BufferedReader(file);
                LinkedList<Event> eventList = new LinkedList<>();
                long start = System.nanoTime();
                String line;
                long total = 0;
                long tmp;

                while ((line = reader.readLine()) != null){
                    Event event = new Event(line.substring(0, 2), Integer.parseInt(line.substring(6, line.length() - 1)));
                    eventList.add(event);
                }

                while (!eventList.isEmpty()) {
                    events++;
                    Event event = eventList.removeFirst();
                    tmp = System.nanoTime();
                    ctx.collect(event);
                    total += System.nanoTime() - tmp;
                    if (timeout != 0 && System.nanoTime() - start >= timeout * 1000000000L) {
                        break;
                    }
                }
                ctx.close();
                Synthetic.executionTime = total;
                try {
                    reader.close();
                }
                catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
            catch (FileNotFoundException | NullPointerException ex){
                ex.printStackTrace();
            }

    //        System.out.println((double)(System.nanoTime() - t1)/1000000000 + ",");
        } else {
            try {
                int timeout = Synthetic.timeout;
                FileReader file = new FileReader(fileName);
                BufferedReader reader = new BufferedReader(file);
                long start = System.nanoTime();
                String line;
                long total = 0;
                long tmp;

                long totalMem = 0;
                long used;
                while ((line = reader.readLine()) != null){
                    if (Synthetic.maxEvents != 0 && events >= Synthetic.maxEvents) {
                        break;
                    }
                    events++;
                    Event event = new Event(line.substring(0, 2), Integer.parseInt(line.substring(6, line.length() - 1)));
                    tmp = System.nanoTime();
                    ctx.collect(event);
                    total += System.nanoTime() - tmp;
                    if (events % 10000 == 0) {
                        System.gc();
                        totalMem = Runtime.getRuntime().totalMemory();
                        Synthetic.avgMemTotal += totalMem;
                        if (totalMem > Synthetic.maxMemTotal) {
                            Synthetic.maxMemTotal = totalMem;
                        }
                        //System.gc();
                        used = totalMem - Runtime.getRuntime().freeMemory();
                        Synthetic.avgMemUsed += used;
                        if (used > Synthetic.maxMemUsed) {
                            Synthetic.maxMemUsed = used;
                        }
                        Synthetic.memMeasurements++;
                    }
                    if (timeout != 0 && System.nanoTime() - start >= timeout * 1000000000L) {
                        //                    System.err.println(event.getId());
                        break;
                    }
                }

                ctx.close();
                Synthetic.executionTime = totalMem;
                try {
                    reader.close();
                }
                catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
                catch (FileNotFoundException | NullPointerException ex){
                ex.printStackTrace();
            }

            //        System.out.println((double)(System.nanoTime() - t1)/1000000000 + ",");

        }
    }

    @Override
    public void cancel() { }
}
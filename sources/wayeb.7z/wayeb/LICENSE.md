Copyright (c) Elias Alevizos

Wayeb comes with ABSOLUTELY NO WARRANTY.

Wayeb follows a dual licensing scheme.

For use by individuals,
Wayeb is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License.
To view a copy of this license, visit https://creativecommons.org/licenses/by-nc-sa/4.0/
or send a letter to Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.
This license is provided exclusively for research purposes. 
The results of any such research involving Wayeb must be made publicly available.

For commercial/institutional/governmental use or any other use by private or public
legal entities, sharing, modifying and distributing Wayeb or any derivatives of it
in any form, such as source code, libraries and executables, requires the written
permission of its author(s) (Elias Alevizos) and a possible request for licensing fees.

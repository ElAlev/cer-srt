package utils

trait Shutdownable {
  def shutdown(): Unit
}

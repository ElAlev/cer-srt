package fsm.symbolic.logic.predicates

import fsm.symbolic.Valuation
import fsm.symbolic.logic.Predicate
import stream.GenericEvent

case class IncGT(override val arguments: List[String]) extends Predicate(arguments) {

  override def evaluate(
                         event: GenericEvent,
                         valuation: Valuation
                       ): Boolean = {
    val isFraud = event.getValueOf("isFraud").toString.toInt
    val fraudType = event.getValueOf("fraudType").toString.toInt
    isFraud == 1 & fraudType == 5
  }

  override def toString: String = "DecGT()"

}

package fsm.symbolic.logic.predicates

import fsm.symbolic.Valuation
import fsm.symbolic.logic.Predicate
import stream.GenericEvent
import utils.StringUtils.list2Str

case class MeetContext(override val arguments: List[String]) extends Predicate(arguments) {

  override def evaluate(
                         event: GenericEvent,
                         valuation: Valuation
                       ): Boolean = {

    val cxt = event.getValueOf("cxt").toString

    if (cxt.equals("meeting"))
      return true
    return false

  }

  override def toString: String = "MeetContext(" + list2Str(arguments, ",") + ")"

}

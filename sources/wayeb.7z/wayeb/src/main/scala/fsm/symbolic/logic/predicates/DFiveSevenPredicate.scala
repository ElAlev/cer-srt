package fsm.symbolic.logic.predicates

import fsm.symbolic.Valuation
import fsm.symbolic.logic.Predicate
import stream.GenericEvent
import utils.StringUtils.list2Str

case class DFiveSevenPredicate(override val arguments: List[String]) extends Predicate(arguments) {
  val port = arguments(0).toDouble.toInt

  override def evaluate(
                         event: GenericEvent,
                         valuation: Valuation
                       ): Boolean = {
    val d57PortsStr = event.getValueOfMap("d57").toString
    if (d57PortsStr == "") false
    else {
      val d57Ports = d57PortsStr.split(",").map(_.trim.toInt)
      d57Ports.contains(port)
    }

  }

  override def toString: String = "D57Predicate(" + list2Str(arguments, ",") + ")"
}

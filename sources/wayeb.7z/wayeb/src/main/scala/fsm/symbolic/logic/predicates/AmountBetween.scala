package fsm.symbolic.logic.predicates

import fsm.symbolic.Valuation
import fsm.symbolic.logic.Predicate
import stream.GenericEvent
import utils.StringUtils.list2Str

case class AmountBetween(override val arguments: List[String]) extends Predicate(arguments) {
  private val min = arguments(0).toDouble
  private val max = arguments(1).toDouble

  override def evaluate(
                         event: GenericEvent,
                         valuation: Valuation
                       ): Boolean = {
    val amount = event.getValueOf("amount").toString.toDouble
    amount >= min & amount < max
  }

  override def toString: String = "AmountBetween(" + list2Str(arguments, ",") + ")"
}

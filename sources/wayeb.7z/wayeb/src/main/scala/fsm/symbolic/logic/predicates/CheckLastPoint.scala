package fsm.symbolic.logic.predicates

import fsm.symbolic.Valuation
import fsm.symbolic.logic.Predicate
import stream.GenericEvent
import utils.StringUtils.list2Str

case class CheckLastPoint(override val arguments: List[String]) extends Predicate(arguments) {
  private val simLength = arguments(0).toDouble.toInt
  private val reductionPercent = arguments(1).toDouble

  override def evaluate(
                         event: GenericEvent,
                         valuation: Valuation
                       ): Boolean = {
    val timestamp = event.getValueOf("Timestamp").toString.toLong
    val aliveNo = event.getValueOf("aliveNo").toString.toDouble.toInt
    val aliveStart = event.getValueOf("prevAliveNo").toString.toDouble.toInt
    timestamp % simLength == 0 & (aliveNo / aliveStart.toDouble) < reductionPercent
  }

  override def toString: String = "CheckLastPoint(" + list2Str(arguments, ",") + ")"

}

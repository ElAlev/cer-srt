package fsm.symbolic.logic.predicates

import fsm.symbolic.Valuation
import fsm.symbolic.logic.Predicate
import stream.GenericEvent
import utils.StringUtils.list2Str

case class Situation(override val arguments: List[String]) extends Predicate(arguments) {
  private val which = arguments(0)
  private val situationToCheck = arguments(1)

  override def evaluate(
                         event: GenericEvent,
                         valuation: Valuation
                       ): Boolean = {
    val situation =
      which match {
        case "one" => event.getValueOf("sit1").toString
        case "two" => event.getValueOf("sit2").toString
        case "group" => event.getValueOf("gsit").toString
        case _ => throw new IllegalArgumentException
      }
    situation.equalsIgnoreCase(situationToCheck)
  }

  override def toString: String = "Situation(" + list2Str(arguments, ",") + ")"

}

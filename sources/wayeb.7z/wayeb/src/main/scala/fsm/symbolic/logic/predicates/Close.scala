package fsm.symbolic.logic.predicates

import fsm.symbolic.Valuation
import fsm.symbolic.logic.Predicate
import stream.GenericEvent
import utils.StringUtils.list2Str

case class Close(override val arguments: List[String]) extends Predicate(arguments) {
  private val minDist = arguments(0).toDouble.toInt
  private val maxDist = arguments(1).toDouble.toInt

  override def evaluate(
                         event: GenericEvent,
                         valuation: Valuation
                       ): Boolean = {
    val distance = event.getValueOf("dist").toString.toInt
    distance >= minDist & distance < maxDist
  }

  override def toString: String = "Close(" + list2Str(arguments, ",") + ")"

}

package fsm.symbolic.sra.nsra

import fsm.symbolic.sra.SRAState

case class NSRAState private[nsra] (override val id: Int) extends SRAState(id) {

}

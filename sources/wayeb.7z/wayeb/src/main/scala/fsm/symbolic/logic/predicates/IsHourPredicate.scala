package fsm.symbolic.logic.predicates

import fsm.symbolic.Valuation
import fsm.symbolic.logic.Predicate
import stream.GenericEvent
import utils.StringUtils.list2Str

case class IsHourPredicate(override val arguments: List[String]) extends Predicate(arguments) {
  override def evaluate(
                         event: GenericEvent,
                         valuation: Valuation
                       ): Boolean = {
    val hour = event.getValueOf("hour").toString.toDouble.toInt
    val hourCheck = arguments(0).toInt
    hour == hourCheck
  }

  override def toString: String = "IsHour(" + list2Str(arguments, ",") + ")"

}

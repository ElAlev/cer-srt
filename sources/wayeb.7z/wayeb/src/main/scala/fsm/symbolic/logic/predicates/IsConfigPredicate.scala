package fsm.symbolic.logic.predicates

import fsm.symbolic.Valuation
import fsm.symbolic.logic.Predicate
import stream.GenericEvent
import utils.StringUtils.list2Str

case class IsConfigPredicate(override val arguments: List[String]) extends Predicate(arguments) {
  override def evaluate(
                         event: GenericEvent,
                         valuation: Valuation
                       ): Boolean = {
    val config = arguments(0).toDouble.toInt
    val configCheck = event.getValueOf("config").toString.toInt
    config == configCheck
  }

  override def toString: String = "IsConfig(" + list2Str(arguments, ",") + ")"

}

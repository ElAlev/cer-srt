package fsm.symbolic.logic.predicates

import fsm.symbolic.Valuation
import fsm.symbolic.logic.Predicate
import stream.GenericEvent
import utils.StringUtils.list2Str
import utils.SpatialUtils.distanceBetween

case class VesselToVesselDistance(override val arguments: List[String]) extends Predicate(arguments) {
  private val min = arguments(0).toDouble
  private val max = arguments(1).toDouble

  override def evaluate(
                         event: GenericEvent,
                         valuation: Valuation
                       ): Boolean = {
    val lon1 = event.getValueOf("lon1").toString.toDouble
    val lat1 = event.getValueOf("lat1").toString.toDouble
    val lon2 = event.getValueOf("lon2").toString.toDouble
    val lat2 = event.getValueOf("lat2").toString.toDouble
    distanceBetween(lon1, lat1, lon2, lat2, min, max)
  }

  override def toString: String = "VesselToVesselDistance(" + list2Str(arguments, ",") + ")"
}

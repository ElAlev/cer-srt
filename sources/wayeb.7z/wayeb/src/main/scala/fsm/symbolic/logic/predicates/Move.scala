package fsm.symbolic.logic.predicates

import fsm.symbolic.Valuation
import fsm.symbolic.logic.Predicate
import stream.GenericEvent
import utils.StringUtils.list2Str

case class Move(override val arguments: List[String]) extends Predicate(arguments) {

  override def evaluate(
                         event: GenericEvent,
                         valuation: Valuation
                       ): Boolean = {

    val situation = event.getValueOf("situation").toString
    situation.equals("moving")

  }

  override def toString: String = "Move(" + list2Str(arguments, ",") + ")"

}

package fsm.symbolic.sra

import fsm.symbolic.AutomatonState

abstract class SRAState(override val id: Int) extends AutomatonState(id) {

}

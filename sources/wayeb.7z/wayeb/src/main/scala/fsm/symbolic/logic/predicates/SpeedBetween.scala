package fsm.symbolic.logic.predicates

import fsm.symbolic.Valuation
import fsm.symbolic.logic.Predicate
import stream.GenericEvent
import utils.StringUtils.list2Str

case class SpeedBetween(override val arguments: List[String]) extends Predicate(arguments) {
  private val min_speed = arguments(0).toDouble
  private val max_speed = arguments(1).toDouble

  override def evaluate(
                         event: GenericEvent,
                         valuation: Valuation
                       ): Boolean = {
    val speed = event.getValueOf("speed").toString.toDouble
    (speed >= min_speed) & (speed < max_speed)
  }

  override def toString: String = "SpeedBetween(" + list2Str(arguments, ",") + ")"

}

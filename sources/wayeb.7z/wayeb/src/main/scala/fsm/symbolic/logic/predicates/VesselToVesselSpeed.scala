package fsm.symbolic.logic.predicates

import fsm.symbolic.Valuation
import fsm.symbolic.logic.Predicate
import stream.GenericEvent
import utils.StringUtils.list2Str

case class VesselToVesselSpeed(override val arguments: List[String]) extends Predicate(arguments) {
  private val min = arguments(0).toDouble
  private val max = arguments(1).toDouble

  override def evaluate(
                         event: GenericEvent,
                         valuation: Valuation
                       ): Boolean = {
    val speed1 = event.getValueOf("speed1").toString.toDouble
    val speed2 = event.getValueOf("speed2").toString.toDouble
    val speedDiff = scala.math.abs(speed1 - speed2)
    (speedDiff >= min) & (speedDiff < max)
  }

  override def toString: String = "VesselToVesselSpeed(" + list2Str(arguments, ",") + ")"

}

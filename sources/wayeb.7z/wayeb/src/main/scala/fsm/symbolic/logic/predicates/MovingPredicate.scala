package fsm.symbolic.logic.predicates

import fsm.symbolic.Valuation
import fsm.symbolic.logic.Predicate
import stream.GenericEvent
import utils.StringUtils.list2Str

case class MovingPredicate(override val arguments: List[String]) extends Predicate(arguments) {
  override def evaluate(
                         event: GenericEvent,
                         valuation: Valuation
                       ): Boolean = {
    val speed = event.getValueOf("speed").toString.toDouble
    speed >= 2.0
  }

  override def toString: String = "MovingPredicate(" + list2Str(arguments, ",") + ")"

}

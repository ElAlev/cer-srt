package fsm.symbolic.logic.predicates

import fsm.symbolic.Valuation
import fsm.symbolic.logic.Predicate
import stream.GenericEvent
import utils.StringUtils.list2Str

case class Context(override val arguments: List[String]) extends Predicate(arguments) {
  private val which = arguments(0)
  private val contextToCheck = arguments(1)

  override def evaluate(
                         event: GenericEvent,
                         valuation: Valuation
                       ): Boolean = {
    val context =
      which match {
        case "one" => event.getValueOf("con1").toString
        case "two" => event.getValueOf("con2").toString
        case "group" => event.getValueOf("gcon").toString
        case _ => throw new IllegalArgumentException
      }
    context.equalsIgnoreCase(contextToCheck)
  }

  override def toString: String = "Context(" + list2Str(arguments, ",") + ")"

}

package fsm.symbolic.sre

object BooleanOperator extends Enumeration {
  type BooleanOperator = Value
  val AND, OR, NOT = Value
}

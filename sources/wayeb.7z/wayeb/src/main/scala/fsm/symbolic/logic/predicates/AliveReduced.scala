package fsm.symbolic.logic.predicates

import fsm.symbolic.Valuation
import fsm.symbolic.logic.Predicate
import stream.GenericEvent
import utils.StringUtils.list2Str

case class AliveReduced(override val arguments: List[String]) extends Predicate(arguments) {
  private val min = arguments(0).toDouble.toInt
  private val max = arguments(1).toDouble

  override def evaluate(
                         event: GenericEvent,
                         valuation: Valuation
                       ): Boolean = {
    val aliveNo = event.getValueOf("aliveNo").toString.toDouble.toInt
    val aliveStart = event.getValueOf("prevAliveNo").toString.toDouble.toInt
    val reduction = aliveNo / aliveStart.toDouble
    reduction >= min & reduction < max
  }

  override def toString: String = "AliveReduced(" + list2Str(arguments, ",") + ")"
}

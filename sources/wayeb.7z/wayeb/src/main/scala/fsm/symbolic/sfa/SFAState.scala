package fsm.symbolic.sfa

import fsm.symbolic.AutomatonState

abstract class SFAState(override val id: Int) extends AutomatonState(id) {

}

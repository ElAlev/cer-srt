package fsm.symbolic.logic.predicates

import fsm.symbolic.Valuation
import fsm.symbolic.logic.Predicate
import stream.GenericEvent
import utils.StringUtils.list2Str

case class VesselToVesselHeading(override val arguments: List[String]) extends Predicate(arguments) {
  private val min = arguments(0).toDouble
  private val max = arguments(1).toDouble

  override def evaluate(
                         event: GenericEvent,
                         valuation: Valuation
                       ): Boolean = {
    val heading1 = event.getValueOf("heading1").toString.toDouble
    val heading2 = event.getValueOf("heading2").toString.toDouble
    val headingDiff = scala.math.abs(heading1 - heading2)
    (headingDiff >= min) & (headingDiff < max)
  }

  override def toString: String = "VesselToVesselHeading(" + list2Str(arguments, ",") + ")"

}

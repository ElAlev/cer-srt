package fsm.symbolic.logic.predicates

import fsm.symbolic.Valuation
import fsm.symbolic.logic.Predicate
import stream.GenericEvent

case class SimilarGaze(override val arguments: List[String]) extends Predicate(arguments) {

  override def evaluate(
                         event: GenericEvent,
                         valuation: Valuation
                       ): Boolean = {

    val gaze1 = event.getValueOf("gaze1").toString.toInt
    val gaze2 = event.getValueOf("gaze2").toString.toInt

    if (gaze1 == -1 || gaze2 == -1)
      return true
    else if (math.abs(gaze1 - gaze2) <= 45)
      return true
    return false

  }

}

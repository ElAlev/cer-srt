package fsm.classical.pattern.regexp

/**
  * A regular expression is represented as a tree.
  */
abstract class RegExpTree





package fsm.classical.pattern.regexp

object OperatorType extends Enumeration {
  type OperatorType = Value
  val NONE, CONCAT, UNION, ITER = Value
}

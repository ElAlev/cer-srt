package fsm.classical.pattern.regexp

object NodeType extends Enumeration {
  type NodeType = Value
  val OPERATOR, SYMBOL = Value
}

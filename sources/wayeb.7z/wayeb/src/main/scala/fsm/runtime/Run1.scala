package fsm.runtime

import com.typesafe.scalalogging.LazyLogging
import fsm.symbolic.TransitionOutput.TAKE
import fsm.symbolic.sfa.IdGenerator
import fsm.symbolic.sra.Configuration
import fsm.{FSMInterface, SNFAInterface}
import stream.GenericEvent

object Run1 {
  def apply(
             fsm: FSMInterface,
             show: Boolean
           ): Run1 = new Run1(fsm, show)
}
class Run1(
            val fsm: FSMInterface,
            val show: Boolean
          ) extends LazyLogging {
  private val window = fsm.getRuntimeWindow
  private val maxCode: Long = Math.pow(2,window).toLong
  private val matchIdGenerator: IdGenerator = IdGenerator()
  private val activeClones: scala.collection.mutable.Map[Int,MatchPool] = scala.collection.mutable.Map.empty //fsm.getStates.map(s => (s,List.empty[Match])).toMap
  fsm.getStates.foreach(s => {
    if (fsm.getStartId == s) {
      val emptyMatch = Match(matchIdGenerator.getIdCautiousMut)
      activeClones += (s -> MatchPool(fsm.getRuntimeWindow, matchIdGenerator, emptyMatch))
    }
    else {
      activeClones += (s -> MatchPool(fsm.getRuntimeWindow, matchIdGenerator))
    }
  })

  private var activeMatches: scala.collection.mutable.Map[Int,List[Long]] = scala.collection.mutable.Map.empty
  private var tmpMatches: scala.collection.mutable.Map[Int,List[Long]] = scala.collection.mutable.Map.empty
  fsm.getStates.foreach(s => {
    if (fsm.getStartId == s) {
      activeMatches += (s -> List(0))
    }
    else {
      activeMatches += (s -> List.empty)
    }
  })
  //activeMatches = tmpMatches

  def clearTmpMatches(): Unit = {
    fsm.getStates.foreach(s => {
      tmpMatches += (s -> List.empty)
    })
  }

  def makeAMove(
                 event: GenericEvent,
                 eventCounter: Long
               ): Int = {
    clearTmpMatches()
    val matchesNo = fsm.getStates.toList.map(state => {
      makeAMoveFromState(event, eventCounter, state)
    })

    /*activeClones.foreach(x => {
      x._2.commit()
    })
    val fullMatchesPools = activeClones.filter(c => fsm.isFinal(c._1)).values
    val fullMatchesNo = fullMatchesPools.map(x => x.retrieveNoOfMatches()).sum
    matchIdGenerator.releaseIdsMut(fullMatchesPools.flatMap(mp => mp.retrieveMatchIds()).toSet)
    fullMatchesPools.foreach(mp => mp.clear())
    fullMatchesNo*/
    activeMatches = tmpMatches.clone()
    matchesNo.sum
  }

  private def makeAMoveFromState(
                                  event: GenericEvent,
                                  eventCounter: Long,
                                  state: Int
                                ): Int = {
    val theseMatches = activeMatches(state).map(m => 2*m).filter(x => x < maxCode)
    var matchesNo = 0
    if (theseMatches.nonEmpty){
      fsm match {
        case x: SNFAInterface => {
          val nextConfs = x.snfa.getDelta(state, event).toList
          if (nextConfs.isEmpty) {
            //theseMatches.clear()
          }
          else {
            val matchesFromConf = nextConfs.map(c => {
              makeAMoveFromStateToConf(event,eventCounter,state,theseMatches,c)
            })
            matchesNo = matchesFromConf.sum
          }
        }
        case _ => throw new Exception()
      }
      matchesNo
    }
    else {
      List.empty
      matchesNo
    }
  }

  private def makeAMoveFromStateToConf(
                                        event: GenericEvent,
                                        eventCounter: Long,
                                        currentState: Int,
                                        theseMatches: List[Long],
                                        nextConf: Configuration
                                      ): Int = {
    val newMatches = if (nextConf.output == TAKE) theseMatches.map(m => m+1) else theseMatches
    val previousMatches = tmpMatches(nextConf.stateId)
    val allMatches = newMatches ::: previousMatches
    tmpMatches += (nextConf.stateId -> allMatches)
    if (fsm.isFinal(nextConf.stateId)) {
      //logger.info("MATCH: " + newMatches)
      //logger.info("MATCH: " + newMatches.map(x => convertCode2Indices(x, eventCounter)))
    }
    val matchesNo = if (fsm.isFinal(nextConf.stateId)) newMatches.size else 0
    matchesNo
  }

  private def convertCode2Indices(
                                   code: Long,
                                   eventCounter: Long
                                 ): List[Long] = {
    val binCode = code.toBinaryString.reverse
    val indices = binCode.zipWithIndex.filter(x => x._1 == '1').map(y => y._2)
    val timestamps = indices.map(x => eventCounter - x)
    timestamps.toList
  }

  private def makeAMoveFromStateToConfWithMatch(
                                                 event: GenericEvent,
                                                 eventCounter: Long,
                                                 currentState: Int,
                                                 m: Match,
                                                 nextConf: Configuration
                                               ): Unit = {

  }


}

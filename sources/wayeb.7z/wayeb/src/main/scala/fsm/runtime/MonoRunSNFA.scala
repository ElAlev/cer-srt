package fsm.runtime

import com.typesafe.scalalogging.LazyLogging
import fsm.WindowType.COUNT
import fsm.symbolic.TransitionOutput.{TAKE, TransitionOutput}
import fsm.{FSMInterface, SNFAInterface}
import stream.GenericEvent

import scala.annotation.tailrec
import scala.collection.mutable

object MonoRunSNFA {
  def apply(
             fsm: FSMInterface,
             show: Boolean,
             postProcess: Boolean
           ): MonoRunSNFA = new MonoRunSNFA(fsm, show, postProcess)
}
class MonoRunSNFA(
                   val fsm: FSMInterface,
                   val show: Boolean,
                   postProcess: Boolean
                 ) extends LazyLogging {

  private val localFinals: mutable.HashSet[Int] = mutable.HashSet.empty
  fsm.getFinals.foreach(f => localFinals += f)
  /*private val localFinals: Array[Int] = new Array[Int](fsm.getFinals.size)
  var i = 0
  private val finalsList = fsm.getFinals.toList
  while (i < fsm.getFinals.size) {
    localFinals(i) =   finalsList(i)
    i += 1
  }

  require(fsm.getFinals.size == 1)
  private val localFinal = fsm.getFinals.head*/

  private var totalTime: Long = 0
  private val runtimeWindow = fsm.getRuntimeWindow
  private var activeStates: Set[Int] = Set(fsm.getStartId)
  private val cachedResults: Array[Array[(Int, TransitionOutput)]] = new Array[Array[(Int, TransitionOutput)]](fsm.getStates.max + 1)

  private var dummyForPostProcessing: Int = 0

  def reset(): Unit = {
    activeStates = Set(fsm.getStartId)
  }

  /*def makeAMove(
                 event: GenericEvent,
                 currentState: Int,
                 eventCounter: Long,
                 matchedEvents: Match
               ): List[(Int, Match)] = {
    val t1 = System.nanoTime()
    val r = if (checkRuntimeWindow(eventCounter, matchedEvents.getMinCounter)) {
      fsm match {
        case x: SNFAInterface => {
          val nextConfs = x.snfa.getDeltaNoConfArrayWhileMutableMap(currentState, event)
          val newMatches = nextConfs.map(nextConf => postProcess(event, nextConf._1, nextConf._2, eventCounter, matchedEvents.clone()))
          val result = nextConfs.map(c => c._1).zip(newMatches.map(m => m._2))
          result
        }
        case _ => throw new Exception()
      }
    }
    else {
      List.empty
    }
    val t2 = System.nanoTime()
    totalTime += t2 - t1
    if (eventCounter % 1000 == 0) logger.debug("Total Run Time: " + totalTime / 1000000 + "@ counter " + eventCounter)
    r
  }

  def makeAMoveArray(
                      event: GenericEvent,
                      currentState: Int,
                      eventCounter: Long,
                      matchedEvents: Match
                    ): List[(Int, Match)] = {
    val t1 = System.nanoTime()
    val r = if (checkRuntimeWindow(eventCounter, matchedEvents.getMinCounter)) {
      fsm match {
        case x: SNFAInterface => {
          val nextConfs = x.snfa.getDeltaNoConfArrayWhileMutableMap(currentState, event).toArray
          var i = 0
          var l = List.empty[(Int,Match)]
          while (i < nextConfs.length) {
            val nextConf = nextConfs(i)
            val newMatch = postProcess(event, nextConf._1, nextConf._2, eventCounter, matchedEvents.clone())
            l = (nextConf._1, newMatch._2) :: l
            i += 1
          }
          l
        }
        case _ => throw new Exception()
      }
    }
    else {
      List.empty
    }
    val t2 = System.nanoTime()
    totalTime += t2 - t1
    if (eventCounter % 1000 == 0) logger.debug("Total Run Time: " + totalTime / 1000000 + "@ counter " + eventCounter)
    r
  }*/

  def updateActiveStates(event: GenericEvent): Unit = {
    var tmpActiveStates = Set.empty[Int]
    fsm match {
      case x: SNFAInterface => {
        while (activeStates.nonEmpty) {
          val currentState = activeStates.head
          val nextConfs = x.snfa.getDeltaNoConfArrayWhileTransitionsArrayPrealloc(currentState, event)
          cachedResults(currentState) = nextConfs
          var i = 0
          while (i < nextConfs.length) {
            val nextConf = nextConfs(i)
            if (nextConf != null) tmpActiveStates += nextConf._1
            i += 1
          }
          activeStates = activeStates.tail
        }
        activeStates = tmpActiveStates
      }
      case _ => {

      }
    }
  }

  def makeAMoveArrayPrealloc(
                      event: GenericEvent,
                      currentState: Int,
                      eventCounter: Long,
                      matchedEvents: MatchList,
                      previousStatesMatches: List[(Int,MatchList)]
                    ): (Int, List[(Int, MatchList)]) = {
    //val t1 = System.nanoTime()
    var newStatesMatches = previousStatesMatches
    var detected = 0
    val r = if (checkRuntimeWindow(eventCounter, event.timestamp, matchedEvents.getMinCounter)) {
      fsm match {
        case x: SNFAInterface => {
          //val nextConfs = x.snfa.getDeltaNoConfArrayWhileTransitionsArrayPrealloc(currentState, event)
          val nextConfs = cachedResults(currentState)
          var i = 0
          //var l = List.empty[(Int, MatchList)]
          while (i < nextConfs.length) {
            val nextConf = nextConfs(i)
            if (nextConf != null) {
              val newMatch = postProcessMatchList(event, nextConf._1, nextConf._2, eventCounter, matchedEvents.clone())
              if (newMatch._1) {
                detected += 1
              }
              else {
                //l = (nextConf._1, newMatch._2) :: l
                newStatesMatches = (nextConf._1, newMatch._2) :: newStatesMatches
              }
            }
            i += 1
          }
          newStatesMatches
        }
        case _ => throw new Exception()
      }
    }
    else {
      previousStatesMatches
    }
    //val t2 = System.nanoTime()
    //totalTime += t2 - t1
    //if (eventCounter % 1000 == 0) logger.debug("Total Run Time: " + totalTime / 1000000 + "@ counter " + eventCounter)
    (detected, r)
  }

  /*private def postProcess(
                           event: GenericEvent,
                           stateId: Int,
                           output: TransitionOutput,
                           eventCounter: Long,
                           matchedEvents: Match
                         ): (Boolean, Match) = {
    val nextState = stateId
    //val detected = fsm.isFinal(nextState)
    val detected = localFinals.contains(nextState)
    if (output == TAKE) matchedEvents.addEvent(event, eventCounter)
    /*if (detected) {
      matchedEvents.setFull(true)
      if (false)
        logger.info(
          "\n\nMATCH: " +
            //"Attr->" + attributeValue +
            " Timestamp->" + event.timestamp.toLong +
            " State->" + nextState +
            " Events->" + matchedEvents.toString() +
            "\n\n"
        )
      matchedEvents.clear()
    }*/
    (detected, matchedEvents)
  }*/

  private def postProcessMatchList(
                           event: GenericEvent,
                           stateId: Int,
                           output: TransitionOutput,
                           eventCounter: Long,
                           matchedEvents: MatchList
                         ): (Boolean, MatchList) = {
    val nextState = stateId
    //val detected = fsm.isFinal(nextState)
    val detected = localFinals.contains(nextState) //(nextState == localFinal) //localFinals.contains(nextState)
    if (output == TAKE) matchedEvents.addEvent(event, eventCounter, fsm.getWindowType)
    //if (detected) {
    //  val retrievedEvents = matchedEvents.getEvents
    //}
    if (detected) {
      matchedEvents.setFull(true)
      if (show) {
        val msg = "\nMATCH: " +
          //"Attr->" + attributeValue +
          " Timestamp->" + event.timestamp.toLong +
          " State->" + nextState +
          " Events->" + matchedEvents.toString() +
          "\n"
        //logger.info(msg)
        System.out.println(msg)
        //val retrievedEvents = matchedEvents.getEvents
        //System.err.println(retrievedEvents.toString())

      }
      else if (postProcess) {
        postProcessMatch(matchedEvents)
      }
      //matchedEvents.clear()
    }
    (detected, matchedEvents)
  }

  private def postProcessMatch(m: MatchList): Unit = postProcessMatchAux(m.getEvents)

  @tailrec
  private def postProcessMatchAux(m: List[Int]): Unit = {
    m match {
      case Nil => {}
      case head::tail => {
        if (head % 10 == 0) dummyForPostProcessing += 1
        postProcessMatchAux(tail)
      }
    }
  }

  private def checkRuntimeWindow(
                                  eventCounter: Long,
                                  eventTimestamp: Long,
                                  minCounter: Long
                                ): Boolean = {
    // if window = 0, this means that there is no window
    if (runtimeWindow == 0) true
    else {
      // if there are no events in the match (minCounter = -1), the window constraint cannot be violated
      if (minCounter == -1) true
      else {
        // the window constraint is violated if the window value is smaller than the interval spanned by the matched
        // events
        val diff = if (fsm.getWindowType == COUNT) Math.abs(eventCounter - minCounter) else Math.abs(eventTimestamp - minCounter)
        (diff < runtimeWindow)
      }
    }
  }

}

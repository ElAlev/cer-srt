package fsm.runtime

import com.typesafe.scalalogging.LazyLogging
import fsm.WindowType.COUNT
import fsm.{FSMInterface, NSRAInterface}
import fsm.symbolic.TransitionOutput.{TAKE, TransitionOutput}
import fsm.symbolic.sra.Configuration
import stream.GenericEvent

import scala.annotation.tailrec
import scala.collection.mutable

object MonoRunNSRA {
  def apply(
             fsm: FSMInterface,
             show: Boolean,
             postProcess: Boolean
           ): MonoRunNSRA = new MonoRunNSRA(fsm, show, postProcess)
}

class MonoRunNSRA(
                   val fsm: FSMInterface,
                   val show: Boolean,
                   postProcess: Boolean
                 ) extends LazyLogging {
  private val localFinals: mutable.HashSet[Int] = mutable.HashSet.empty
  fsm.getFinals.foreach(f => localFinals += f)
  private var totalTime: Long = 0
  private val runtimeWindow = fsm.getRuntimeWindow

  private var dummyForPostProcessing: Int = 0

  def reset(): Unit = {

  }

  def makeAMoveArrayPrealloc(
                              event: GenericEvent,
                              currentConf: Configuration,
                              eventCounter: Long,
                              matchedEvents: MatchList,
                              previousStatesMatches: List[(Configuration, MatchList)]
                            ): (Int, List[(Configuration, MatchList)]) = {
    var newStatesMatches = previousStatesMatches
    var detected = 0
    val r = if (checkRuntimeWindow(eventCounter, event.timestamp, matchedEvents.getMinCounter)) {
      fsm match {
        case x: NSRAInterface => {
          val nextConfs = x.nsra.yieldsSuccessorConfigNoEpsilonOpt(currentConf, event)
          var i = 0
          var l = List.empty[(Configuration, MatchList)]
          while (i < nextConfs.length) {
            val nextConf = nextConfs(i)
            if (nextConf != null) {
              val newMatch = postProcessMatchList(event, nextConf.stateId, nextConf.output, eventCounter, matchedEvents.clone())
              if (newMatch._1) {
                detected += 1
              }
              else {
                l = (nextConf, newMatch._2) :: l
                newStatesMatches = (nextConf, newMatch._2) :: newStatesMatches
              }
            }
            i += 1
          }
          newStatesMatches
        }
        case _ => throw new Exception()
      }
    }
    else {
      previousStatesMatches
    }
    (detected, r)
  }

  private def postProcessMatchList(
                                    event: GenericEvent,
                                    stateId: Int,
                                    output: TransitionOutput,
                                    eventCounter: Long,
                                    matchedEvents: MatchList
                                  ): (Boolean, MatchList) = {
    val nextState = stateId
    //val detected = fsm.isFinal(nextState)
    val detected = localFinals.contains(nextState)
    if (output == TAKE) matchedEvents.addEvent(event, eventCounter, fsm.getWindowType)
    if (detected) {
      matchedEvents.setFull(true)
      if (show) {
        val msg = "\nMATCH: " +
          //"Attr->" + attributeValue +
          " Timestamp->" + event.timestamp.toLong +
          " State->" + nextState +
          " Events->" + matchedEvents.toString() +
          "\n"
        //logger.info(msg)
        System.out.println(msg)
      }
      else if (postProcess) {
        postProcessMatch(matchedEvents)
      }
      matchedEvents.clear()
    }
    (detected, matchedEvents)
  }

  private def postProcessMatch(m: MatchList): Unit = postProcessMatchAux(m.getEvents)

  @tailrec
  private def postProcessMatchAux(m: List[Int]): Unit = {
    m match {
      case Nil => {}
      case head :: tail => {
        if (head % 10 == 0) dummyForPostProcessing += 1
        postProcessMatchAux(tail)
      }
    }
  }

  private def checkRuntimeWindow(
                                  eventCounter: Long,
                                  eventTimestamp: Long,
                                  minCounter: Long
                                ): Boolean = {
    // if window = 0, this means that there is no window
    if (runtimeWindow == 0) true
    else {
      // if there are no events in the match (minCounter = -1), the window constraint cannot be violated
      if (minCounter == -1) true
      else {
        // the window constraint is violated if the window value is smaller than the interval spanned by the matched
        // events
        val diff = if (fsm.getWindowType == COUNT) Math.abs(eventCounter - minCounter) else Math.abs(eventTimestamp - minCounter)
        (diff < runtimeWindow)
      }
    }
  }

}

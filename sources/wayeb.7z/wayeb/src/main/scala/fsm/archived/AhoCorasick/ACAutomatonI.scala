package fsm.archived.AhoCorasick

private[AhoCorasick] trait ACAutomatonI {
  def buildACA(): ACAutomaton
}

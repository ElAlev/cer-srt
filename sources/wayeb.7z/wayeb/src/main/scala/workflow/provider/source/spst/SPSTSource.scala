package workflow.provider.source.spst

abstract class SPSTSource {

}

package workflow.provider.source.spstm

abstract class SPSTmSource {

}

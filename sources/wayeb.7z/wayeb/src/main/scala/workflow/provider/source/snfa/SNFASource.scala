package workflow.provider.source.snfa

abstract class SNFASource {

}

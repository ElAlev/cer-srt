package workflow.provider.source.forecaster

abstract class ForecasterSource {

}

package workflow.provider.source.order

class OrderSourceDirect(val order: Int) extends OrderSource {

}

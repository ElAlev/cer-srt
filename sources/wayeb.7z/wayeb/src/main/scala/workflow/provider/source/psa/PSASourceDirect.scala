package workflow.provider.source.psa

import model.vmm.pst.psa.ProbSuffixAutomaton

class PSASourceDirect(val psa: List[ProbSuffixAutomaton]) extends PSASource {

}

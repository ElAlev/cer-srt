package workflow.provider.source.spsa

abstract class SPSASource {

}

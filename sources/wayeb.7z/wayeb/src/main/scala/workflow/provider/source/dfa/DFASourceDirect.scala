package workflow.provider.source.dfa

import fsm.classical.fa.dfa.DFA

class DFASourceDirect(val dfa: List[DFA]) extends DFASource {

}

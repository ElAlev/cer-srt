package workflow.provider.source.hmm

abstract class HMMSource {

}

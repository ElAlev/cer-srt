package workflow.task.engineTask

import com.typesafe.scalalogging.LazyLogging
import engine.ERFOptEngine
import profiler.WtProfiler
import stream.source.StreamSource
import workflow.provider.FSMProvider
import workflow.task.Task

object ERFOptTask {
  def apply(
             fsmp: FSMProvider,
             show: Boolean,
             postProcess: Boolean,
             warmupFirst: Boolean,
             warmupStreamSize: Int,
             findWarmupLimit: Boolean,
             batchLength: Int,
             measurements: Int,
             streamSource: StreamSource,
             reset: Boolean,
             timeout: Long,
             memoryTest: Boolean
           ): ERFOptTask = new ERFOptTask(fsmp, show, postProcess, warmupFirst, warmupStreamSize, findWarmupLimit, batchLength, measurements, streamSource, reset, timeout, memoryTest)
}

class ERFOptTask private (
                           fsmp: FSMProvider,
                           show: Boolean,
                           postProcess: Boolean,
                           warmupFirst: Boolean,
                           warmupStreamSize: Int,
                           findWarmupLimit: Boolean,
                           batchLength: Int,
                           measurements: Int,
                           streamSource: StreamSource,
                           reset: Boolean,
                           timeout: Long,
                           memoryTest: Boolean
                         ) extends Task with LazyLogging{

  private val engine = ERFOptEngine(fsmp, show, postProcess, warmupFirst, warmupStreamSize, findWarmupLimit, batchLength, measurements, reset, memoryTest)

  override def execute(): WtProfiler = {
    logger.info("Executing ERF task...")
    streamSource.emitEventsToListener(engine, timeout)
    val profiler = engine.getProfiler
    logger.info("done.")
    profiler
  }
}

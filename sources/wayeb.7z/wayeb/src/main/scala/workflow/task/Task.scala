package workflow.task

trait Task {
  def execute(): Object
}

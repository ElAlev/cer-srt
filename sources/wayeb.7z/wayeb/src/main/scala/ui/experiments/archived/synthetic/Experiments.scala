package ui.experiments.archived.synthetic

object Experiments {
  def main(args: Array[String]): Unit = {
    val sdfaConfigs: List[ConfigSDFA] = Config1.configs
  }

}

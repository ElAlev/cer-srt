package ui.experiments.archived.text

object Constants {
  val dataDir: String = System.getenv("TEXTDIR")
  val wayebHome: String = System.getenv("WAYEB_HOME")

}

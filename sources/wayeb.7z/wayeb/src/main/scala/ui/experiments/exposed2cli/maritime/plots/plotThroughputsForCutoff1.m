setname = 'ThroughputClassification';
home = getenv('WAYEB_HOME');
resultsDir = strcat(home, '/results/maritime/');
resultsFiles = {strcat(resultsDir,'portSingleVesselDistance1SPSTClassification_0_0001.csv'),strcat(resultsDir,'portSingleVesselDistance1SPSTClassification_0_001.csv'),strcat(resultsDir,'portSingleVesselDistance1SPSTClassification_0_01.csv'),strcat(resultsDir,'portSingleVesselDistance1SPSTClassification_0_1.csv'),strcat(resultsDir,'portSingleVesselDistance1SPSTClassification_0_2.csv')};

orders = [1 2 3 4 5 6];
modelLabels = {'m=1','m=2','m=3','m=4','m=5','m=6'};
maxSpread = 10;

minDistances = [0.0];
maxDistances = [0.5];

cutoffThresholds = [0.0001 0.001 0.01 0.1 0.2];

totalOrdersNo = size(orders,2);
data1 = zeros(size(cutoffThresholds,2),totalOrdersNo);

for c=1:size(cutoffThresholds,2)
    cutoffThreshold = cutoffThresholds(c);
    resultsFile = resultsFiles{c};
    results = csvread(resultsFile,1,0);
    [throughputs, states] = gatherThroughputs(minDistances,maxDistances,orders,maxSpread,results);
    data1(c,1:totalOrdersNo) = throughputs;
end

groupsNo = size(cutoffThresholds,2);
labels = cell(groupsNo,1);
for g=1:groupsNo
    labels{g} = num2str(cutoffThresholds(g));
end
figure('units','normalized','outerposition',[0 0 1 1],'visible','on');
b = bar(data1);
b(1).FaceColor = 'g';
b(2).FaceColor = 'r';
b(3).FaceColor = 'b';
b(4).FaceColor = 'y';
b(5).FaceColor = 'm';
b(6).FaceColor = 'k';
grid on;
%grid minor;
xlabel('Cutoff Threshold');
set(gca,'XTickLabel',labels);
ylabel('Throughput (events/sec)');
legend(modelLabels,'Location','north','Orientation','horizontal','FontSize',34);
figureTitle = setname;
%title(figureTitle);
set(gcf,'Color','w');
set(gca,'FontSize',44);
pdfTitle = strcat(figureTitle, '.pdf')
export_fig(strcat(resultsDir,pdfTitle));

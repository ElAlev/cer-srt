setname = 'PortClassNextKROC';
home = getenv('WAYEB_HOME');
resultsDir = strcat(home, '/results/maritime/');
prefices = {'0_0001', '0_001', '0_01', '0_1', '0_2'};
resultsFiles = {strcat(resultsDir,'portSingleVesselDistance1SPSTClassification_0_0001.csv'),strcat(resultsDir,'portSingleVesselDistance1SPSTClassification_0_001.csv'),strcat(resultsDir,'portSingleVesselDistance1SPSTClassification_0_01.csv'),strcat(resultsDir,'portSingleVesselDistance1SPSTClassification_0_1.csv'),strcat(resultsDir,'portSingleVesselDistance1SPSTClassification_0_2.csv')};

orders = [1 2 3 4 5 6];
modelLabels = {'m=1','m=2','m=3','m=4','m=5','m=6'};


resultSetsNo = size(resultsFiles,2);

minDistance = 0.0;
maxDistance = 0.5;

cutoffThresholds = [0.0001 0.001 0.01 0.1 0.2];

barsno = size(orders,2);
allaucs = zeros(size(cutoffThresholds,2),barsno);

for c=1:size(cutoffThresholds,2)
    cutoffThreshold = cutoffThresholds(c);
    aucs = [];
    resultsFile = resultsFiles{c};
    results = csvread(resultsFile,1,0);
    prefix = strcat(setname, prefices{c});
    aucs = [aucs roc(minDistance,maxDistance,orders,results,prefix,resultsDir)' ];
    allaucs(c,:) = aucs;

    figure('units','normalized','outerposition',[0 0 1 1],'visible','off');
    bar(aucs);
    grid on;
    grid minor;
    set(gca, 'YLim',[0,1]);
    ylabel('AUC');
    figureTitle = strcat('minDist=',num2str(minDistance),'maxDist=',num2str(maxDistance));
    title(figureTitle);
    set(gca,'XTickLabel',modelLabels);
    pdfTitle = strcat(setname, 'AUC', figureTitle, '.pdf')
    export_fig(strcat(resultsDir,pdfTitle));
end

figure('units','normalized','outerposition',[0 0 1 1],'visible','off');
b = bar(allaucs);

b(1).FaceColor = 'g';
b(2).FaceColor = 'r';
b(3).FaceColor = 'b';
b(4).FaceColor = 'y';
b(5).FaceColor = 'm';
b(6).FaceColor = 'k';

grid on;
%grid minor;
ylabel('AUC');
xlabel('Cutoff Threshold')
set(gca, 'YLim',[0.4,1]);
%set(gca,'YTickLabels',[0 0.2 0.4 0.6 0.8 1]);
legend(modelLabels,'Location','north','Orientation','horizontal','FontSize',34);
set(gcf,'Color','w');
set(gca,'FontSize',44);
ticklabels = cell(1,size(cutoffThresholds,2));
for c=1:size(cutoffThresholds,2)
    label = num2str(cutoffThresholds(c));
    ticklabels{c} = label;
end
set(gca,'XTickLabel',ticklabels);
pdfTitle = strcat(setname, 'AUCALL', '.pdf')
export_fig(strcat(resultsDir,pdfTitle));

figure('units','normalized','outerposition',[0 0 1 1],'visible','off');
b = bar3(allaucs); %,'stacked');
v = [0.8 1.0 0.6];
view(v);
grid on;
grid minor;
set(gcf,'Color','w');
set(gca,'FontSize',32);
set(gca,'YTickLabel',ticklabels);
set(gca,'XTickLabel',modelLabels);
set(gca, 'ZLim',[0,1]);
pdfTitle = strcat(setname, 'AUCALL3d', '.pdf')
export_fig(strcat(resultsDir,pdfTitle));

package ui.demo

import ui.WayebCLI

object RunCLIsrem {

  final val home: String = System.getenv("WAYEB_HOME")
  final val dataDir: String = home + "/data/demo/"   //"/data/maritime/"
  final val resultsDir: String = home + "/results"
  final val testDatasetFilename: String = dataDir + "data.csv" //"227592820.csv"
  final val trainDatasetFilename: String = dataDir + "data.csv" //"227592820.csv"
  final val patternFile: String = home + "/patterns/validation/testsrem.sre" //"/patterns/validation/speedIncrease.sre"
  final val declarationsFile: String = ""
  final val domain: String = "csv"
  final val threshold = 0.50
  final val maxSpread = 50
  final val horizon = 50
  final val spreadMethod = "classify-nextk"

  def main(args: Array[String]): Unit = {
    //runCompile("speedIncrease")
    //runRec("speedIncrease")
    //runTrainVMM("speedIncrease")
    //runTestVMM("speedIncrease")

    runNSRACompile("testnsra")
    runNSRARec("testnsra")
  }

  private def runNSRACompile(patternName: String): Unit = {
    val fsm = resultsDir + "/" + patternName + ".fsm"
    val argsTest: Array[String] = Array(
      "compile",
      "--patterns:" + patternFile,
      "--fsmModel:nsra",
      "--outputFsm:" + fsm
    )
    WayebCLI.main(argsTest)
  }

  private def runNSRARec(patternName: String): Unit = {
    val fsm = resultsDir + "/" + patternName + ".fsm"
    val stats = resultsDir + "/" + patternName + ".stats.rec"
    val argsTest: Array[String] = Array(
      "recognition",
      "--fsm:" + fsm,
      "--fsmModel:nsra",
      "--stream:" + testDatasetFilename,
      "--domainSpecificStream:" + domain,
      "--streamArgs:",
      "--statsFile:" + stats
    )
    WayebCLI.main(argsTest)
  }

  private def runCompile(patternName: String): Unit = {
    val fsm = resultsDir + "/" + patternName + ".fsm"
    val argsTest: Array[String] = Array(
      "compile",
      "--patterns:" + patternFile,
      "--fsmModel:dsra",
      "--outputFsm:" + fsm
    )
    WayebCLI.main(argsTest)
  }

  private def runRec(patternName: String): Unit = {
    val fsm = resultsDir + "/" + patternName + ".fsm"
    val stats = resultsDir + "/" + patternName + ".stats.rec"
    val argsTest: Array[String] = Array(
      "recognition",
      "--fsm:" + fsm,
      "--fsmModel:dsra",
      "--stream:" + testDatasetFilename,
      "--domainSpecificStream:" + domain,
      "--streamArgs:",
      "--statsFile:" + stats
    )
    WayebCLI.main(argsTest)
  }

  private def runTrainVMM(patternName: String): Unit = {
    val spstm = resultsDir + "/" + patternName + ".spstm"
    val argsTrain: Array[String] = Array(
      "learnSPST",
      "--patterns:" + patternFile,
      "--declarations:" + declarationsFile,
      "--stream:" + trainDatasetFilename,
      "--domainSpecificStream:" + domain,
      "--streamArgs:",
      "--outputSpst:" + spstm,
      "--fsmModel:dsra"
    )
    WayebCLI.main(argsTrain)
  }

  private def runTestVMM(patternName: String): Unit = {
    val fsm = resultsDir + "/" + patternName + ".spstm"
    val stats = resultsDir + "/" + patternName + ".stats"
    val argsTest: Array[String] = Array(
      "forecasting",
      "--threshold:" + threshold,
      "--maxSpread:" + maxSpread,
      "--spreadMethod:" + spreadMethod,
      "--horizon:" + horizon,
      "--modelType:vmm",
      "--fsm:" + fsm,
      "--stream:" + testDatasetFilename,
      "--domainSpecificStream:" + domain,
      "--streamArgs:",
      "--statsFile:" + stats,
      "--fsmModel:dsra"
    )
    WayebCLI.main(argsTest)
  }
}

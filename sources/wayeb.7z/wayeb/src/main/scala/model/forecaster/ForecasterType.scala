package model.forecaster

object ForecasterType extends Enumeration {
  type ForecasterType = Value
  val REGRESSION, CLASSIFICATION = Value
}

package engine

import com.typesafe.scalalogging.LazyLogging
import fsm.runtime._
import fsm.symbolic.sra.Configuration
import fsm.{FSMInterface, NSRAInterface, SNFAInterface}
import profiler.WtProfiler
import stream.source.{EndOfStreamEvent, StreamListener}
import stream.{GenericEvent, ResetEvent}
import ui.ConfigUtils
import utils.MathUtils
import workflow.provider.FSMProvider

object ERFOptEngine {
  def apply(
             fsmProvider: FSMProvider,
             show: Boolean,
             postProcess: Boolean,
             warmupFirst: Boolean,
             warmupStreamSize: Int,
             findWarmupLimit: Boolean,
             batchLength: Int,
             measurements: Int,
             reset: Boolean,
             memoryTest: Boolean
           ): ERFOptEngine = new ERFOptEngine(fsmProvider, show, postProcess, warmupFirst, warmupStreamSize, findWarmupLimit, batchLength, measurements, reset, memoryTest)
}

class ERFOptEngine(
                    fsmProvider: FSMProvider,
                    show: Boolean,
                    postProcess: Boolean,
                    warmupFirst: Boolean,
                    warmupStreamSize: Int,
                    findWarmupLimit: Boolean,
                    batchLength: Int,
                    measurements: Int,
                    reset: Boolean,
                    memoryTest: Boolean
                  ) extends StreamListener with LazyLogging {
  require(!(warmupFirst & findWarmupLimit), "You can either try to find the warmup limit or run the engine with warmup")
  logger.info("Initializing engine...")

  private val singlePartitionVal = ConfigUtils.singlePartitionVal
  private val fsmList = fsmProvider.provide()
  private val runPool = RunPool(fsmList, ConfigUtils.defaultExpiration, ConfigUtils.defaultDistance, show)

  private var eventCounterInBatch: Int = 0
  private var currentLatencyAccumulator: Long = 0

  private var throughputAcc: List[Long] = List.empty
  val indep: List[Double] = (1 to measurements).toList.map(x => x.toDouble)
  private val throughputEpsilon: Double = 0.001
  private var slope: Double = throughputEpsilon + 1

  private var matchesNo = 0
  private var execTime: Long = 0
  private var totalStreamSize: Int = 0
  private var effectiveStreamSize: Int = 0
  private var firstTimestamp: Long = 0
  private var lastTimestamp: Long = 0
  private var totalRuns: Long = 0
  private var profiler = WtProfiler()

  private var runIds: List[Int] = List.empty
  private val monoRunSNFAPool: List[MonoRunSNFA] = fsmList.map(fsm => MonoRunSNFA(fsm, show, postProcess))
  private var currentStatesMatches: List[(Int,MatchList)] = monoRunSNFAPool.map(r => (r.fsm.getStartId,MatchList()))
  private val monoRunNSRAPool: List[MonoRunNSRA] = fsmList.map(fsm => MonoRunNSRA(fsm, show, postProcess))
  private var currentConfsMatches: List[(Configuration,MatchList)] = monoRunNSRAPool.map(r => (Configuration(r.fsm.getStartId),MatchList()))

  private val runPool1: List[Run1] = fsmList.map(fsm => Run1(fsm, show))

  var maxMemTotal: Long = 0
  var avgMemTotal: Long = 0
  var maxMemUsed: Long = 0
  var avgMemUsed: Long = 0
  var countMemMeas: Int = 0

  logger.info("Initialization complete.")

  override def newEventEmitted(event: GenericEvent): Unit = {
    event match {
      /**
       * Every stream must contain an EndOfStreamEvent as its last event.
       * Upon the arrival of such an event, statistics are estimated and provided through a profiler.
       */
      case _: EndOfStreamEvent => {
        profiler = shutdown()
        logger.info("Use getProfiler to retrieve stats.")
      }
      case _ => {
        totalStreamSize += 1
        if (totalStreamSize % 100000 == 0) logger.debug(event.toString)
        //processEvent(event)
        processEventOpt(event)
        if (memoryTest & totalStreamSize % 10000 == 0) memoryMeasure()
        //processEventWithMonoRunSNFA(event)
        //processEvent1FoldedRuns(event)
        if (findWarmupLimit) {
          if (eventCounterInBatch == batchLength) {
            //val latencyDiff: Long = Math.abs(currentLatencyAccumulator - previousLatencyAccumulator)
            //val latencyDiffPercent: Double = latencyDiff.toDouble / previousLatencyAccumulator
            val throughput = (batchLength.toDouble / (currentLatencyAccumulator.toDouble / 1000000000)).toInt
            throughputAcc = throughput :: throughputAcc
            if (throughputAcc.size > measurements) throughputAcc = throughputAcc.dropRight(1)
            logger.info("\n\tCurrent throughput: " + throughput)
            logger.info("\n\tLast throughputs: " + throughputAcc)
            if (throughputAcc.size >= measurements) {
              val throughputAccMax = throughputAcc.max
              val throughputAccNorm = throughputAcc.map(x => x.toDouble / throughputAccMax)
              val result = MathUtils.slopeInterceptLinearLeastSquares(indep, throughputAccNorm.reverse.map(x => x.toDouble)) //MathUtils.slopeInterceptLinearLeastSquares(List(2,3,5,7,9),List(4,5,7,10,15))
              slope = result._1
              logger.info(result.toString())
            }
            if (Math.abs(slope) < throughputEpsilon) {
              logger.info("\n\nThroughput stabilised at " + totalStreamSize + " events with throughput: " +  throughput + "  !\n\n")
              profiler = shutdown()
              profiler.printProfileInfo()
              System.exit(1)
            }
            else {
              eventCounterInBatch = 1
              //previousLatencyAccumulator = currentLatencyAccumulator
              currentLatencyAccumulator = 0
            }
          }
          else {
            eventCounterInBatch += 1
          }
        }
      }
    }
  }

  private def memoryMeasure(): Unit = {
    System.gc()
    var total: Long = Runtime.getRuntime.totalMemory
    avgMemTotal += total
    if (total > maxMemTotal) maxMemTotal = total
    //System.gc()
    var used: Long = total - Runtime.getRuntime.freeMemory
    avgMemUsed += used
    if (used > maxMemUsed) maxMemUsed = used
    countMemMeas += 1
  }

  private def processEvent(event: GenericEvent): Unit = {
    val t1 = System.nanoTime()
    // All FSMs process the event.
    val det = fsmList.map(fsm => processEvent(event, fsm))
    if (outOfWarmup) {
      effectiveStreamSize += 1
      matchesNo += det.map(d => d._1).sum
      val ts: Long = event.getValueOf("Timestamp").toString.toLong
      if (totalStreamSize == 1) firstTimestamp = ts
      lastTimestamp = ts
      val t2 = System.nanoTime()
      val thisLatency = (t2 - t1)
      currentLatencyAccumulator += thisLatency
      execTime += thisLatency
    }
  }

  private def outOfWarmup: Boolean = (!warmupFirst) | (warmupFirst & totalStreamSize > warmupStreamSize)

  /*private def processEvent1FoldedRuns(event: GenericEvent): Unit = {
    val t1 = System.nanoTime()
    val result = runPool1.map(run => processEvent1FoldedRuns(event, run, totalStreamSize))
    if (outOfWarmup) {
      effectiveStreamSize += 1
      matchesNo += result.map(x => x._1).sum
      //logger.debug("\n\tMatches thus far: " + matchesNo)
      val t2 = System.nanoTime()
      val thisLatency = (t2 - t1)
      currentLatencyAccumulator += thisLatency
      execTime += thisLatency
    }
  }

  private def processEvent1FoldedRuns(
                                       event: GenericEvent,
                                       thisRun: Run1,
                                       eventCounter: Long
                                     ): (Int, Long) = {
    val t1 = System.nanoTime()
    val noOfCompleteMatches = thisRun.makeAMove(event, eventCounter)
    val t2 = System.nanoTime()
    (noOfCompleteMatches, t2 - t1)
  }*/

  private def processEventOpt(event: GenericEvent): Unit = {
    fsmList.foreach {
      case _: SNFAInterface => processEventWithMonoRunSNFA(event)
      case _: NSRAInterface => processEventWithMonoRunNSRA(event)
      case _ => throw new Exception()
    }
  }

  private def processEventWithMonoRunSNFA(event: GenericEvent): Unit = {
    val t1 = System.nanoTime()
    val result = monoRunSNFAPool.map(run => processEventWithMonoRunSNFA(event, run, totalStreamSize))
    if (outOfWarmup) {
      effectiveStreamSize += 1
      val newMatchesNo = result.map(x => x._1).sum
      matchesNo += newMatchesNo
      if (reset & newMatchesNo > 0) resetMonoRunSNFA()
      val t2 = System.nanoTime()
      val thisLatency = (t2 - t1)
      currentLatencyAccumulator += thisLatency
      execTime += thisLatency
    }
  }

  private def processEventWithMonoRunSNFA(
                                           event: GenericEvent,
                                           thisRun: MonoRunSNFA,
                                           eventCounter: Long
                                         ): (Int, Long) = {
    val t1 = System.nanoTime()
    thisRun.updateActiveStates(event)
    var tmpStatesMatches = List.empty[(Int,MatchList)]
    var detected: Int = 0
    while (currentStatesMatches.nonEmpty) {
      val stateMatch = currentStatesMatches.head
      val result = thisRun.makeAMoveArrayPrealloc(event, stateMatch._1, eventCounter, stateMatch._2, tmpStatesMatches)
      detected += result._1
      tmpStatesMatches = result._2
      currentStatesMatches = currentStatesMatches.tail
    }
    currentStatesMatches = tmpStatesMatches
    //logger.debug(currentStatesMatches.toString())
    val noOfCompleteMatches = detected
    val t2 = System.nanoTime()
    (noOfCompleteMatches, t2 - t1)
  }

  private def resetMonoRunSNFA(): Unit = {
    currentStatesMatches = monoRunSNFAPool.map(r => (r.fsm.getStartId,MatchList()))
    monoRunSNFAPool.foreach(r => r.reset())
  }

  private def processEventWithMonoRunNSRA(event: GenericEvent): Unit = {
    val t1 = System.nanoTime()
    val result = monoRunNSRAPool.map(run => processEventWithMonoRunNSRA(event, run, totalStreamSize))
    if (outOfWarmup) {
      effectiveStreamSize += 1
      val newMatchesNo = result.map(x => x._1).sum
      matchesNo += newMatchesNo
      if (reset & newMatchesNo > 0) resetMonoRunNSRA()
      val t2 = System.nanoTime()
      val thisLatency = (t2 - t1)
      currentLatencyAccumulator += thisLatency
      execTime += thisLatency
    }
  }

  private def resetMonoRunNSRA(): Unit = {
    currentConfsMatches= monoRunNSRAPool.map(r => (Configuration(r.fsm.getStartId),MatchList()))
    monoRunNSRAPool.foreach(r => r.reset())
  }

  private def processEventWithMonoRunNSRA(
                                           event: GenericEvent,
                                           thisRun: MonoRunNSRA,
                                           eventCounter: Long
                                         ): (Int, Long) = {
    val t1 = System.nanoTime()
    var tmpConfsMatches = List.empty[(Configuration,MatchList)]
    //logger.debug("BEFORE:" + currentConfsMatches.toString())
    var detected: Int = 0
    while (currentConfsMatches.nonEmpty) {
      val confMatch = currentConfsMatches.head
      //logger.debug("CHECKING: " + confMatch.toString())
      val result = thisRun.makeAMoveArrayPrealloc(event, confMatch._1, eventCounter, confMatch._2, tmpConfsMatches)
      //logger.debug("RESULT: " + result)
      detected += result._1
      tmpConfsMatches = result._2
      currentConfsMatches = currentConfsMatches.tail
    }
    currentConfsMatches = tmpConfsMatches
    //logger.debug("AFTER:" + currentConfsMatches.toString())
    totalRuns += currentConfsMatches.size
    System.out.println("ACTIVE RUNS: " + currentConfsMatches.size)
    System.out.println("TOTAL RUNS: " + totalRuns)
    val noOfCompleteMatches = detected
    val t2 = System.nanoTime()
    (noOfCompleteMatches, t2 - t1)
  }

  private def processEvent(
                            event: GenericEvent,
                            thisFsm: FSMInterface
                          ): (Int, Long) = {
    /**
     * First find the appropriate run(s).
     * Exactly one run per FSM is possible (and all FSMs attempt to process the event) for deterministic FSM.
     * For non-deterministic FSM, multiple runs may need to be considered.
     */
    val partitionAttribute = thisFsm.getPartitionAttribute
    // First retrieve the value of the  partition attribute,
    // i.e., the attribute by which the input stream is to be partitioned.
    val av = if (partitionAttribute.equalsIgnoreCase(singlePartitionVal)) singlePartitionVal
    else event.getValueOf(partitionAttribute).toString
    val runs = findRuns(event, thisFsm)
    var detected: Int = 0
    var processingTime: Long = 0
    thisFsm match {
      case _: SNFAInterface => {
        val results = runs.map(r => processEventAtRunNonDet(event, r, av))
        detected = results.map(_._1).sum
        processingTime = results.map(_._2).sum
      }
      case _: NSRAInterface => {
        val results = runs.map(r => processEventAtRunNonDet(event, r, av))
        detected = results.map(_._1).sum
        processingTime = results.map(_._2).sum
      }
      case _ => {
        processingTime = runs.map(r => r.processEventDet(event)).sum
        detected = runs.map(r => r.ceDetected).count(_ == true)
      }
    }
    (detected, processingTime)
  }

  private def processEventAtRunNonDet(
                                       event: GenericEvent,
                                       run: Run,
                                       attributeVal: String
                                     ): (Int, Long) = {
    val t1 = System.nanoTime()
    var detected: Int = 0
    event match {
      case _: ResetEvent => killRun(run, attributeVal)
      case _ => {
        // First check whether the run is ready to process the event.
        // For SPST(m) we might need to wait for a couple of events before we can start processing.
        // Other FSM types should always be ready.
        val ready = run.checkForReadiness(event)
        if (ready) {
          // find the next configurations
          val nextConfs = run.findNextConfigurations(event).toList
          if (nextConfs.nonEmpty) {
            // If there are more than one next configurations, we need to clone the run.
            // If there are k next configurations, we need to create k-1 clones (from the tail), so that we have a total
            // of k runs.
            val newRuns = nextConfs.tail.map(conf => runPool.checkOut(run, attributeVal, event.timestamp, conf))
            val allRuns = run :: newRuns
            //logger.debug("ACTIVE RUNS: " + allRuns.size)
            val statesAndRuns = nextConfs.zip(allRuns)
            // For all of the k runs, now try to produce forecasts (has an effect only in forecasting)
            statesAndRuns.foreach(sr => {
              val run = sr._2
              run.emitForecasts(event, sr._1)
            })
            detected = allRuns.count(r => r.ceDetected)
          }
          else {
            // if no next configurations have been found, this means that the run has nowhere to go,
            // therefore we need to kill it
            killRun(run, attributeVal)
          }
        }
      }
    }
    val t2 = System.nanoTime()
    val pt: Long = t2 - t1
    (detected, pt)
  }

  private def findRuns(
                        event: GenericEvent,
                        thisFsm: FSMInterface
                      ): List[Run] = {
    val fsmId = thisFsm.getId
    val partitionAttribute = thisFsm.getPartitionAttribute
    // First retrieve the value of the  partition attribute,
    // i.e., the attribute by which the input stream is to be partitioned.
    val av = if (partitionAttribute.equalsIgnoreCase(singlePartitionVal)) singlePartitionVal
    else event.getValueOf(partitionAttribute).toString
    // If the pool of runs already has a run with this partition value (for the ID of the FSM we
    // are examining), then get this run.
    if (runPool.existsRunWithAttributeVal(fsmId, av)) {
      runPool.getRunsByAttribute(fsmId, av)
    } // Otherwise, create a new run with this partition value.
    else {
      val r1 = runPool.checkOut(fsmId, av, event.timestamp)
      List(r1)
    }
  }

  private def killRun(
                       run: Run,
                       attributeVal: String
                     ): Unit = {
    runPool.release(run.fsm.getId, attributeVal, run.id)
  }

  private def shutdown(): WtProfiler = {
    logger.info("Shutting down...")
    val (locked, unlocked) = runPool.getSize
    val profiler = WtProfiler()
    profiler.setGlobal(
      streamSize = effectiveStreamSize,
      firstTimestamp = firstTimestamp,
      lastTimestamp = lastTimestamp,
      execTime = execTime,
      matchesNo = matchesNo,
      lockedRuns = locked,
      unlockedRuns = unlocked,
      matchDump = new MatchDump
    )
    if (memoryTest) profiler.setMemStats(maxMemTotal, avgMemTotal, maxMemUsed, avgMemUsed, countMemMeas)
    profiler.estimateStats()
    runPool.shutdown()
    logger.info("done.")
    profiler
  }

  def getProfiler: WtProfiler = profiler

}

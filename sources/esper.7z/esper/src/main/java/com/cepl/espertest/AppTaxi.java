package com.cepl.espertest;

import com.espertech.esper.common.client.EPCompiled;
import com.espertech.esper.common.client.configuration.Configuration;
import com.espertech.esper.compiler.client.CompilerArguments;
import com.espertech.esper.compiler.client.EPCompileException;
import com.espertech.esper.compiler.client.EPCompilerProvider;
import com.espertech.esper.runtime.client.EPDeployException;
import com.espertech.esper.runtime.client.EPDeployment;
import com.espertech.esper.runtime.client.EPRuntime;
import com.espertech.esper.runtime.client.EPRuntimeProvider;

import java.io.*;
import java.util.LinkedList;
import java.util.Scanner;

public class AppTaxi {

    public static void run(String[] args) throws FileNotFoundException, EPCompileException, EPDeployException {
        long maxMemTotal = 0;
        long avgMemTotal = 0;
        long maxMemUsed = 0;
        long avgMemUsed = 0;
        int memMeasurements = 0;
        long totalMem = Runtime.getRuntime().totalMemory();
        System.gc();
        long usedMem = totalMem - Runtime.getRuntime().freeMemory();

        String stream_file = args[1];
        boolean memoryTest = Boolean.parseBoolean(args[2]);
        boolean double_letter = Boolean.parseBoolean(args[3]);
        int max_events = args.length > 4 ? Integer.parseInt(args[4]) : 0;
        int timeout = args.length > 5 ? Integer.parseInt(args[5]) : 0;
        boolean printMatches = args.length > 6 ? Boolean.parseBoolean(args[6]) : false;
        boolean postProcess = args.length > 7 ? Boolean.parseBoolean(args[7]) : true;
        int limit = args.length > 8 ? Integer.parseInt(args[8]) : -1;

        String entireFileText = new Scanner(new File(args[0]))
                .useDelimiter("\\A").next();

        long startCompileTime = System.nanoTime();

        Configuration configuration = new Configuration();
        configuration.getCommon().addEventType(TaxiEvent.class);
        EPRuntime engine = EPRuntimeProvider.getDefaultRuntime(configuration);
        CompilerArguments compilerArguments = new CompilerArguments(configuration);
        compilerArguments.getPath().add(engine.getRuntimePath());

        EPCompiled compiled = EPCompilerProvider.getCompiler().compile(entireFileText, compilerArguments);

        EPDeployment statement = engine.getDeploymentService().deploy(compiled);
        long compileTime = System.nanoTime() - startCompileTime;

        EventListener el = new EventListener();
        el.setLimit(limit);
        el.setPrintMatches(printMatches);
        el.setPostProcess(postProcess);
        el.setDomain("taxi");
        statement.getStatements()[0].addListener(el);

        FileReader file;
        BufferedReader stream;

        if (!memoryTest) {
            try {
                file = new FileReader(stream_file);
                stream = new BufferedReader(file);

                String line;
                int events = 0;
                TaxiEvent ev;
                LinkedList<TaxiEvent> eventsList = new LinkedList<>();
                long t0 = System.nanoTime();
                while (max_events == 0 || events <= max_events) {
                    line = stream.readLine();
                    if (line == null) {
                        break;
                    }
                    events++;
                    eventsList.add(TaxiEvent.getEventFromString(line));
                }

                long start = System.nanoTime();
                int events2 = 0;

                long execTime = 0;

                while (!eventsList.isEmpty()) {
                    ev = eventsList.removeFirst();
                    long timeBefore = System.nanoTime();
                    engine.getEventService().sendEventBean(ev, "TaxiEvent");
                    long timeAfter = System.nanoTime();
                    execTime += (timeAfter - timeBefore);
                    if (timeout != 0 && timeAfter - start > timeout * 1000000000L) {
                        break;
                    }
                    events2++;
                }

                double totalRunTimenSec = (double)(System.nanoTime() - start)/1000000000;
                System.out.print(totalRunTimenSec + ",");
                System.out.print(events2 + ",");
                //                System.out.print((((double)parsingTime) / 1000000000) + ",");
                //                System.out.print((((double)compileTime) / 1000000000) + ",");
                //                System.out.print((((double)total) / 1000000000) + ",");
                double enumTimeSec = (double)(EventListener.enumTime) / 1000000000L;
                double execTimeSec = (double)(execTime) / 1000000000L;
                System.out.print(enumTimeSec + ",");
                System.out.print(EventListener.totalMatches + ",");
                System.out.print(execTimeSec + ",");
                double throughputTotal =  ((double) (events2)) / totalRunTimenSec;
                double throughputExec =  ((double) (events2)) / execTimeSec;
                double throughputEnum =  ((double) (events2)) / enumTimeSec;
                if (enumTimeSec == 0) throughputEnum = -1;
                System.out.print(throughputExec + ",");
                System.out.print(throughputEnum);
                System.out.println();

                stream.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        else {
            try {
                file = new FileReader(stream_file);
                stream = new BufferedReader(file);

                String line;
                int events = 0;
                long start = System.nanoTime();

                while (max_events == 0 || events <= max_events) {
                    line = stream.readLine();
                    if (line == null) {
                        break;
                    }
                    events++;
                    engine.getEventService().sendEventBean(TaxiEvent.getEventFromString(line), "TaxiEvent");

                    if (events % 10000 == 0) {
                        System.gc();
                        totalMem = Runtime.getRuntime().totalMemory();
                        avgMemTotal += totalMem;
                        if (totalMem > maxMemTotal) {
                            maxMemTotal = totalMem;
                        }
                        //System.gc();
                        usedMem = totalMem - Runtime.getRuntime().freeMemory();
                        avgMemUsed += usedMem;
                        if (usedMem > maxMemUsed) {
                            maxMemUsed = usedMem;
                        }
                        memMeasurements++;
                    }

                    if (timeout != 0 && System.nanoTime() - start > timeout * 1000000000L) {
                        break;
                    }
                }

                if (memMeasurements == 0) {
                    memMeasurements = 1;
                }

                System.out.print(maxMemTotal + ",");
                System.out.print(avgMemTotal / memMeasurements + ",");
                System.out.print(maxMemUsed + ",");
                System.out.print(avgMemUsed / memMeasurements + ",");
                System.out.println(memMeasurements);

                stream.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

    }
}

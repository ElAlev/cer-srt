package com.cepl.espertest;

import com.espertech.esper.common.client.EventBean;
import com.espertech.esper.common.internal.event.map.MapEventBean;
import com.espertech.esper.runtime.client.EPRuntime;
import com.espertech.esper.runtime.client.EPStatement;
import com.espertech.esper.runtime.client.UpdateListener;

import java.lang.reflect.Array;
import java.util.Collection;

public class EventListener implements UpdateListener{
    public static long enumTime = 0;
    public static long totalMatches = 0;
    public static int count = 0;
    public static int limit = -1;
    public static boolean printMatches = false;
    public static boolean postProcess = true;

    public static int dummyForPostProcessing = 0;

    public static String domain = "synthetic";

    public void setLimit(int l) {
        limit = l;
    }

    public void setPrintMatches(boolean pm) {
        printMatches = pm;
    }

    public void setPostProcess(boolean pp) {
        postProcess = pp;
    }

    public void setDomain(String d) {domain = d;}

    public static String getEPL(){
        // return "select a, b, c from pattern @DiscardPartialsOnMatch" +
        //        "[ every ( [1:] ( [1:] a=MyEvent(type='A') until b=MyEvent(type='B') ) until c=MyEvent(type='C') ) ]";
        return "select a, b, c from MyEvent "
                   + "match_recognize ( "
                   + "    measures A as a, B as b, C as c"
                   + "    all matches "
                   + "    pattern ( A s* B s* C ) "
                   + "    define "
                   + "        A as A.type = \"A\" and A.id < 100, "
                   + "        B as B.type = \"B\" and B.id >= 0, "
                   + "        C as C.type = \"C\")"; // and C.id < 50, "
                //    + "        D as D.type = \"D\")";
    }

    @Override
    public void update(EventBean[] newData, EventBean[] oldData, EPStatement epStatement, EPRuntime epRuntime) {
        // when sending count
        //         System.out.println("MATCH: " + newData[0].get("count") + " diferent outputs");

        count = 0;
        // when sending all results
        long startTime = System.nanoTime();
        //        System.err.println("Match found!:");
        for (EventBean bean: newData) {
            if (limit != -1 & count >= limit) {
                break;
            }
            totalMatches++;
            //System.out.println("Match: " + totalMatches);
            //System.out.println(((MapEventBean) bean).getProperties().toString());
            if (printMatches) {
                System.err.println(((MapEventBean) bean).getProperties().toString());
            }
            else if (postProcess) {
                //EventBean myev = bean;
                //System.out.println(myev.getUnderlying().toString());
                //BuySellEvent mybs = (BuySellEvent) myev.getUnderlying();
                Object[] simpleEvents = ((MapEventBean) bean).getProperties().values().toArray();
                for (Object ev: simpleEvents) {
                    if (ev.hashCode() % 10 ==0) dummyForPostProcessing++;
                    // Code below does not seem to work. Casting to a specific event type (e.g. TaxiEvent) produces
                    // wrong results. Some complex events are not detected. Casting seems to mess with the engine,
                    // essentially "deleting" events after having been cast and making them unavailable for further
                    // matching. Happens with Kleene patterns. Seems to be working with simpler sequential patterns.
                    /*if (domain.equalsIgnoreCase("synthetic")) {
                        if (((MyEvent) ev).getId() % 10 == 0) dummyForPostProcessing++;
                    } else if (domain.equalsIgnoreCase("stock")) {
                        if (((BuySellEvent) ev).getId() % 10 == 0) dummyForPostProcessing++;
                    } else if (domain.equalsIgnoreCase("smart")) {
                        if (((SmartHomesEvent) ev).getId() % 10 == 0) dummyForPostProcessing++;
                    } else if (domain.equalsIgnoreCase("taxi")) {
                        if (((TaxiEvent) ev).getId() % 10 == 0) dummyForPostProcessing++;
                    }*/
                }
            }
            enumTime += System.nanoTime() - startTime;
            count++;

        }
        //         System.out.println("- MATCH TRIGGERED AT B(id=" + newData[0].get("b_id") + ").");
        //enumTime += System.nanoTime() - startTime;
    }
}

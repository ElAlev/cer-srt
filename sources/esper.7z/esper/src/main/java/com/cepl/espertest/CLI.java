package com.cepl.espertest;

public class CLI {
    public static String domain = "synthetic";

    public static void main(String[] args) throws Exception {
        domain = args[0];
        String[] newArgs = new String[args.length - 1];
        for (int i = 1, j = 0; i < args.length; i++) {
            newArgs[j++] = args[i];
        }
        if (domain.equalsIgnoreCase("synthetic")) {
            AppSynthetic.run(newArgs);
        }
        else if (domain.equalsIgnoreCase("stock")) {
            AppStock.run(newArgs);
        }
        else if (domain.equalsIgnoreCase("smart")) {
            AppSmartHomes.run(newArgs);
        }
        else if (domain.equalsIgnoreCase("taxi")) {
            AppTaxi.run(newArgs);
        }
        else {
            throw new IllegalArgumentException("what is this domain?");
        }
    }
}

package com.cepl.espertest;

public class MyEvent {
    private String type;
    private int id;

    public MyEvent(String type, int id){
        this.type = type;
        this.id = id;
    }

	public int getId() {
		return id;
    }
    
    public String getType() {
		return type;
    }
    
    @Override
    public String toString(){
        return type + "(id=" + id + ")";
    }

    static public MyEvent getEventFromString(String line) {
        MyEvent toReturn = new MyEvent(line.substring(0, 2), Integer.parseInt(line.substring(6, line.length() - 1)));
        return toReturn;
    }
}
